/**
 * 
 */
package com.demo.discount.assessment.retailsite.builder;

import java.util.List;

import com.demo.discount.assessment.retailsite.entity.Bill;
import com.demo.discount.assessment.retailsite.entity.ShoppingItem;
import com.demo.discount.assessment.retailsite.entity.User;


public interface BillOperations {

	public void collectUserInfo(User user);

	public Double getGroceriedItemCost(List<ShoppingItem> shoopingItemList);

	public Double collectPurchasedItems(List<ShoppingItem> shoopingItemList);

	public Double userTypeDiscountApply(Double cost);

	public Double totalBillDiscountApply(Double cost);
	
	public String printBillDetails(Bill bill);

}
