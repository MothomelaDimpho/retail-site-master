
package com.demo.discount.assessment.retailsite.entity;


public enum ShoppingItemCategory {
	CLOTHS, CAR_ACCESSORIES, ELECTRONICS, GROCERIES, ANIMALS_FOOD, OTHER
}
